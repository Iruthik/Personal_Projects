from django.shortcuts import render , redirect
from .models import ContactMessage
from django.contrib import messages 

def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone', '')
        message_text = request.POST.get('message')

        # Save to database
        ContactMessage.objects.create(
            name=name,
            email=email,
            phone=phone,
            message=message_text
        )

        # Show success message
        messages.success(request, "Thank you! Your message has been sent.")

        return redirect('contact')

    return render(request, 'contact.html')